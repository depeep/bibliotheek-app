
// const apiUrl = 'http://localhost:3000/leners';
// const uitleenUrl = 'http://localhost:3000/uitleen/'; // endpoint voor uitleengegevens

// document.getElementById('zoekBtn').addEventListener('click', zoekUitgeleendOpLener);

// async function zoekUitgeleendOpLener() {
//     const zoekLener = document.getElementById('zoekNaam').value.trim();
//     const resultDiv = document.getElementById("ResultaatlenerId");
//     resultDiv.innerHTML = "";

//     if (!zoekLener) {
//         alert("Voer een naam in om te zoeken.");
//         return;
//     }

//     resultDiv.innerHTML = "Zoeken...";

//     try {
//         const response = await fetch(`${apiUrl}?naam=${zoekLener}`);
//         if (!response.ok) throw new Error("Fout bij zoeken");

//         const data = await response.json();
//         if (data.length === 0) {
//             resultDiv.innerHTML = "Geen lener gevonden";
//             return;
//         }

//         // Maak lijst van gevonden leners
//         const ul = document.createElement('ul');
//         data.forEach(lener => {
//             const li = document.createElement('li');
//             li.textContent = `ID: ${lener.id}, Naam: ${lener.naam} `;

//             const button = document.createElement('button');
//             button.textContent = 'kies';
//             button.addEventListener('click', () => zoekBoekId(lener.id));

//             li.appendChild(button);
//             ul.appendChild(li);
//         });

//         resultDiv.innerHTML = "<h3>Gevonden leners:</h3>";
//         resultDiv.appendChild(ul);

//     } catch (error) {
//         resultDiv.innerHTML = "Er is een fout opgetreden: " + error.message;
//     }
// }

// async function zoekBoekId(id) {
//     const resultDiv = document.getElementById('ResultaatlenerId');
//     resultDiv.innerHTML = `Gekozen Lener ID: ${id}<br>Uitleengegevens worden opgehaald...`;

//     try {
//         // const response = await fetch(`${uitleenUrl}): ?lenersid=${id}`);
//         const response = await fetch(`${uitleenUrl}?lenersid=${id}`);
//         if (!response.ok) throw new Error("Fout bij ophalen uitleengegevens");

//         const uitleenData = await response.json();
//         if (uitleenData.length === 0) {
//             resultDiv.innerHTML += "<br>Geen uitleengegevens gevonden.";
//             return;
//         }

//         const ul = document.createElement('ul');
//         uitleenData.forEach(item => {
//             const li = document.createElement('li');
//             li.textContent = `Boekid: ${item.titel}, Datum: ${item.datum}`;
//             ul.appendChild(li);
//         });

//         resultDiv.innerHTML += "<h4>Uitleengegevens:</h4>";
//         resultDiv.appendChild(ul);

//     } catch (error) {
//         resultDiv.innerHTML += "<br>Fout: " + error.message;
//     }
// }


const apiUrl = 'http://localhost:3000/leners';
const uitleenUrl = 'http://localhost:3000/uitleen'; // endpoint voor uitleengegevens

async function zoekUitgeleendOpLener() {
    const zoekLener = document.getElementById('zoekNaam').value.trim();
    if (!zoekLener) {
        alert("Voer een naam in om te zoeken.");
        return;
    }

    const resultDiv = document.getElementById("ResultaatlenerId");
    resultDiv.innerHTML = "Zoeken...";

    try {
        const response = await fetch(`${apiUrl}?naam=${zoekLener}`);
        if (!response.ok) throw new Error("Fout bij zoeken");

        const data = await response.json();
        if (data.length === 0) {
            resultDiv.innerHTML = "Geen lener gevonden";
            return;
        }

        // Maak lijst van gevonden leners
        let html = "<h3>Gevonden leners:</h3><ul>";
        data.forEach(lener => {
            html += `
                <li>
                    ID: ${lener.id}, Naam: ${lener.naam}
                    <button onclick="selectLener(${lener.id})">kies</button>
                </li>
            `;
        });
        html += "</ul>";
        resultDiv.innerHTML = html;

    } catch (error) {
        resultDiv.innerHTML = "Er is een fout opgetreden: " + error.message;
    }
}

// Functie om geselecteerde lener te tonen en uitleengegevens op te halen (transactieid)
async function selectLener(id) {
    const resultDiv = document.getElementById('ResultaatlenerId');
    resultDiv.innerHTML = `Gekozen Lener ID: ${id}<br>Uitleengegevens worden opgehaald...`;

    try {
        const response = await fetch(`${uitleenUrl}?lenersid=${id}`);
        if (!response.ok) throw new Error("Fout bij ophalen uitleengegevens");

        const uitleenData = await response.json();
        if (uitleenData.length === 0) {
            resultDiv.innerHTML += "<br>Geen uitleengegevens gevonden.";
            return;
        }

        let html = "<h4>Uitleengegevens:</h4><ul>";
        uitleenData.forEach(item => {
            html += `<li>Boek: ${item.transactieid}, Datum: ${item.datum}</li>
            <button onclick="selectBoekgegevens(${item.transactieid})">kies</button>`;
        });

        html += "</ul>";
        resultDiv.innerHTML += html;

    } catch (error) {
        resultDiv.innerHTML += "<br>Fout: " + error.message;
    }
}

//uitleengegevens zoeken op transactieid
// Functie om geselecteerde lener te tonen en uitleengegevens op te halen (transactieid)
async function selectBoekgegevens(id) {
    const resultDiv = document.getElementById('ResultaatlenerId');
    resultDiv.innerHTML = `Gekozen transactie ID: ${id}<br>Uitleengegevens worden opgehaald...`;

    try {
        const response = await fetch(`${uitleenUrl}/terugbrengen?transactieid=${id}`);
        if (!response.ok) throw new Error("Fout bij ophalen uitleengegevens");

        const uitleenData = await response.json();
        if (uitleenData.length === 0) {
            resultDiv.innerHTML += "<br>Geen uitleengegevens gevonden.";
            return;
        }

        let html = "<h4>Uitleengegevens:</h4><ul>";
        uitleenData.forEach(item => {
            html += `<li>Boek: ${item.titel}, Datum: ${item.datum}</li>`;
        });
        html += "</ul>";
        resultDiv.innerHTML += html;

    } catch (error) {
        resultDiv.innerHTML += "<br>Fout: " + error.message;
    }
}