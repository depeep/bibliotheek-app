Eerst express mysql2 en cors installeren:

npm install express mysql2 cors
